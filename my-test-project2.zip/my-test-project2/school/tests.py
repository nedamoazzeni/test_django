from django.test import TestCase
from .models import Student, Teacher, Classroom
from django.urls import reverse
# Create your tests here.

class ModelTestCase(TestCase):
    def setUp(self):
        self.classroom = Classroom.objects.create(name="دوم",grade=2)
        self.teacher = Teacher.objects.create(name="لیلا",last_name="میرزایی",role="معلم")
        
        
    def test_create_student(self):
        student = Student.objects.create(name="ملیکا",last_name="حیدری",classroom=self.classroom,teacher=self.teacher)
        self.assertEqual(student.name,"ملیکا")
        self.assertEqual(student.last_name,"حیدری")
        self.assertEqual(student.classroom.name,"دوم")
        self.assertEqual(student.teacher.name,"لیلا")
        self.assertEqual(student.teacher.last_name,"میرزایی")
        
 
class  ViewTestCase(TestCase):
    def setUp(self):
        classroom = Classroom.objects.create(name="سوم",grade="3")
        teacher = Teacher.objects.create(name="زهرا",last_name="کریمی",role="معلم")
        Student.objects.create(name="هدیه",last_name="طاهری",classroom=classroom,teacher=teacher)
        
    def test_student_list_view(self):
        response = self.client.get(reverse('student_list'))
        self.assertEqual(response.status_code,200)
        self.assertContains(response,"هدیه")