from django.db import models

# Create your models here.
class ClassRoom(models.Model):
    name = models.CharField(max_length=50,verbose_name='کلاس')
    
    def __str__(self):
        return f"{self.name}"
    
    class Meta:
        verbose_name=' کلاس '
        verbose_name_plural=' کلاس ها'
class Staff(models.Model):
    name = models.CharField(max_length=50,verbose_name='نام')
    last_name = models.CharField(max_length=50,verbose_name='نام خانوادگی')
    job_title = models.CharField(max_length=30,verbose_name= 'پست شغلی')
    grade = models.CharField(max_length=30,verbose_name='مقطع',blank=True, null=True)
    photo = models.ImageField(upload_to='staff_photos/',verbose_name='عکس')
    def __str__(self):
        return f"{self.name}---{self.last_name}----{self.grade}----{self.photo}"
    class Meta:
        verbose_name='کادر مدرسه'
        verbose_name_plural='کادر مدرسه'
class Student(models.Model):
    national_code = models.CharField(max_length=10, unique=True,verbose_name='')
    name = models.CharField(max_length=50,verbose_name='نام')
    last_name = models.CharField(max_length=50,verbose_name='نام خانوتدگی')
    class_room = models.ForeignKey(ClassRoom,verbose_name='کلاس', on_delete=models.CASCADE)
    teacher = models.ForeignKey(Staff,verbose_name='معلم', on_delete=models.SET_NULL ,null=True, blank=True)
    grade = models.FloatField(verbose_name='معدل')
    photo = models.ImageField(upload_to='student_phptos/',verbose_name='عکس')
    
    def __str__(self):
        return f"{self.name}---{self.last_name}---{self.class_room}"
    class Meta:
        verbose_name='دانش آموز'
        verbose_name_plural='دانش آموران'