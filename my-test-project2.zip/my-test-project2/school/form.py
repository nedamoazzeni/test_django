from django import forms
class NationalCodeSearchForm(forms.Form):
    national_code = forms.CharField(
        label= 'کد ملی دانش آموز',
        max_length= 10,
        widget= forms.TextInput(attrs={
            'placehoder':'1451213257',
            'class':'form-control',
        })
    )
    def clean_national_code(self):
        national_code = self.cleaned_data['national_code']
        if not national_code.isdigit():
            raise forms.ValidationError("کد ملی باید فقط عدد باشد")
        if len(national_code)!=10:
            raise forms.ValidationError("کد ملی باید 10 رقمی باشد")
        return national_code