from django.shortcuts import render
from django.shortcuts import redirect, get_object_or_404
from .models import Staff, Student, ClassRoom
from .form import NationalCodeSearchForm
# Create your views here.

def index(request):
    if request.method == 'POST':
        form = NationalCodeSearchForm(request.POST)
        if form.is_valid:
            national_code =form.cleaned_data['national_code']
            try:
                student = Student.objects.get(national_code=national_code)
                return redirect('student_detail', student_id=student.id)
            except Student .DoesNotExist:
                return render(request, 'school/index.html', {'error:دانش آموزی با این کد ملی یافت نشد'})
    else:
        form= NationalCodeSearchForm()
    return render(request,'school/index.html')

def staff_view(request):
    staff = Staff.objects.all()
    return render(request,'school/staff.html',{'staff':staff})

def class_list(request):
    classes = ClassRoom.objects.all()
    return render(request,'school/classes.html',{'classes':classes})

def class_detail(request, class_id):
    class_room = get_object_or_404(ClassRoom, id=class_id)
    students = Student.objects.filter(class_room=class_room)
    return render(request,'school/class_detail.html',{'class_room': class_room, 'students': students, })
 
def student_detail(request, student_id):
       student = get_object_or_404(Student, id=student_id)
       return render(request,'school/student_detail.html',{'student':student})