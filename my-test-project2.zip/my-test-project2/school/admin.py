from django.contrib import admin
from .models import Staff , Student , ClassRoom
from django.utils.html import format_html
# Register your models here.
class AdminClassRoom(admin.ModelAdmin):
    list_display=['name']
    list_filter=['name']
admin.site.register(ClassRoom,AdminClassRoom)
class AdminStaff(admin.ModelAdmin):
    def PhotoStaff(self,obj):
        return format_html('<img src="{}" style="max-width:200px;"max-height:200px"/>'.format(obj.photo.url))
    list_display=['name','last_name','job_title','PhotoStaff']
    list_filter=['name','last_name','job_title']
admin.site.register(Staff,AdminStaff)
class AdminStudent(admin.ModelAdmin):
    def PhotoStudent(self,obj):
        return format_html('<img src="{}" style="max-width:200px;"max-height:200px"/>'.format(obj.photo.url))
    list_display=['name','last_name','national_code','class_room','teacher','grade','PhotoStudent']
    list_editable=['grade']
    list_filter=['name','last_name','teacher','class_room']
admin.site.register(Student,AdminStudent)