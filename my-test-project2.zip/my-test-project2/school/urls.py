from django.urls import path
from . import views

urlpatterns = [
    path('',views.index, name='index'),
    path('staff/',views.staff_view, name='staff'),
    path('classes/',views.class_list, name='classes'),
    path('class/<int:class_id>/',views.class_detail, name='class_detail'),
    path('student/<int:student_id>/',views.student_detail, name='student_detail'),
]
